package com.amw.labs.SpringHelloWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHelloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
